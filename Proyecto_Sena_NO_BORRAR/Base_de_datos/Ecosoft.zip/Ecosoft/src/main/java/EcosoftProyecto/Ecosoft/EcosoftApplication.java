package EcosoftProyecto.Ecosoft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcosoftApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcosoftApplication.class, args);
	}

}
